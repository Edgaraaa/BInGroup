#include <iostream>
#include <cstdio>
#define MAX 1024
#define Error 0xffffff
using namespace std;

class stack_by_edgar {
private:
    int sp = 0;
    int bp = 0;
    int val[MAX] = { 0 };
public:
    int pop()
    {
        if (this->is_empty() == 1)
        {
            printf("ERROE STACK IS EMPTY------------------[*]\n");
            return Error;
        }
        int retval = this->val[sp];
        this->sp--;
        return retval;
    }
    void push(int num)
    {
        if (this->is_full() == 1)
        {
            printf("ERROR STACK IS FULL------------------[*]\n");
            return;
        }
        this->sp++;
        this->val[sp] = num;
    }
    bool is_full()
    {
        if (this->sp >= MAX)
        {
            return 1;
        }
        return 0;
    }
    bool is_empty()
    {
        if (this->sp <= this->bp)
        {
            return 1;
        }
        return 0;
    }
    void clear()
    {
        this->sp = 0;
        this->bp = 0;
        memset(this->val, 0, sizeof(this->val));
    }
    int pop_bp()
    {
        if (this->is_empty() == 1)
        {
            printf("ERROR STACK IS EMPTY\n");
        }
        int retval = this->val[this->bp];
        this->bp++;
        return retval;
    }
};

int main()
{
    stack_by_edgar a;
    a.push(1);
    a.push(2);
    a.push(3);
    int kkp = a.pop();
    kkp = a.pop();
    kkp = a.pop();
    kkp = a.pop();
    cout << kkp;
    return 0;
}
