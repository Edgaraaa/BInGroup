#include <iostream>
#include <string>
#include "hnc.cpp"
using namespace std;

 int main()
{
	stark <string> t1;
	int flag1=1;
	char work;
	for(;flag1==1;)
	{
		cin>>work;
		switch (work)
		{
  		 case '+': t1.putin(); break;
		 case '-': t1.putout(); break;
		 case '!': flag1=0; break;
		 case '=': t1.putoutt();break;
		 case '~': t1.Clear();break;
		}
	}
	return 0;
}

