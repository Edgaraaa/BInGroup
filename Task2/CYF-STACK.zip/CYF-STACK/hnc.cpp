#include <iostream>
#include <string>
#define N 10

using namespace std;

template <class t>
class stark
{
public:

	void Clear()
	{
	    int i=0;
	    for(;i<10;++i)
        {
            a[i]='0';
        }
        this->flag=0;
	}
	void putoutt()
	{
		if((this->flag>-1)?1:0)
		{
			cout<<a[0]<<endl;
			a[0] = '0';
		}
	}
	void putin()
{
	if((this->flag<N)?1:0)
	{
		cin>>a[this->flag];
		cout<<this->flag+1<<"/10"<<endl;
			this->flag++;
	}
	else
	{
			if(this->flag==N)
	{
		cout<<"FULL"<<endl;
	}
	else if(this->flag==-1)
	{
		cout<<"EMPTY"<<endl;
	}
	}
}
	void putout()
{
	this->flag--;
	if((this->flag>-1)?1:0)
	{
		cout<<a[this->flag]<<" "<<endl;
		cout<<this->flag<<"/10"<<endl;
	}
	else
	{
			if(this->flag==N)
	{
		cout<<"FULL"<<endl;
	}
	else
	{
		cout<<"EMPTY"<<endl;
	}
		this->flag++;
	}
}


	~stark()
	{
		cout<<"END"<<endl;
	}
private:
	t a[N];
	int flag=0;
};








